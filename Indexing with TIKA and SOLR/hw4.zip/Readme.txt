Nodeclient consists of all the code written

While using MOSS, ignore the node_modules directory.
Use server.js and public/index.html


Steps to run program ( I assume you have nodejs installed)

1. In the terminal go to the nodeclient directory
2. In server.js, there are two post handlers. Each post handler has a "url" variable.
	Inside the url variable, make changes to the name of the core, port number etc.
3. Run the command
	node server.js
4. Open any browser and open "localhost:8080"
5. The program is now running